package android.jmichalek.jaymichalekwguscheduler.All.UI;

public class AssessmentAdapter {
}
